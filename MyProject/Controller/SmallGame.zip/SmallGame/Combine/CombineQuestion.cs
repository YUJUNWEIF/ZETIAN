﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace geniusbaby.Combine
{
    class CombineQuestion
    {
        public IExpNode GenWithArithmeticSeries(int Count)
        {
            int MaxDelta = 8 / (Count - 1);
            int Delta = UnityEngine.Random.Range(0, MaxDelta);
            int MaxStart = 9 - Delta * (Count - 1);
            //int start = UnityEngine.Random.Range(0, MaxStart);
            int start = UnityEngine.Random.Range(1, MaxStart);
            int[] Candicate = new int[Count];
            List<IExpNode> en = new List<IExpNode>(Count);
            for (int index = 0; index < Count; ++index)
            {
                Candicate[index] = start + index * Delta;
                en.Add(new ValueNode(Candicate[index]));
            }
            return Use(en);
        }

        public IExpNode GenTwoGroup()
        {
            //int a = UnityEngine.Random.Range(0, 10);
            //int b = UnityEngine.Random.Range(0, 10);
            int a = UnityEngine.Random.Range(1, 10);
            int b = UnityEngine.Random.Range(1, 10);
            int[] Candicate = new int[4];
            Candicate[0] = a;
            Candicate[1] = a;
            Candicate[2] = b;
            Candicate[3] = b;
            List<IExpNode> en = new List<IExpNode>(4);
            for (int index = 0; index < Candicate.Length; ++index)
            {
                en.Add(new ValueNode(Candicate[index]));
            }
            return Use(en);
        }

        IExpNode Use(List<IExpNode> candicate)
        {
            if (candicate.Count <= 1) return candicate[0];

            int param1Index = UnityEngine.Random.Range(0, candicate.Count);
            IExpNode param1 = candicate[param1Index];
            candicate.RemoveAt(param1Index);

            int param2Index = UnityEngine.Random.Range(0, candicate.Count);
            IExpNode param2 = candicate[param2Index];
            candicate.RemoveAt(param2Index);

            switch (UnityEngine.Random.Range(0, 4))
            {
                case 0: candicate.Add(GenAddExp(param1, param2)); break;
                case 1: candicate.Add(GenSubExp(param1, param2)); break;
                case 2: candicate.Add(GenMulExp(param1, param2)); break;
                case 3: candicate.Add(GenDivExp(param1, param2)); break;
            }
            return Use(candicate);
        }
        IExpNode GenAddExp(IExpNode param1, IExpNode param2)
        {
            if (param1.Value + param2.Value < 100)
            {
                return new ExpNode(LEXICAL.LEX_ADD, param1, param2);
            }
            return GenSubExp(param1, param2);
        }
        IExpNode GenSubExp(IExpNode param1, IExpNode param2)
        {
            if (param1.Value > param2.Value)
            {
                return new ExpNode(LEXICAL.LEX_SUB, param1, param2);
            }
            return new ExpNode(LEXICAL.LEX_SUB, param2, param1);
        }
        IExpNode GenMulExp(IExpNode param1, IExpNode param2)
        {
            if (param1.Value * param2.Value < 100)
            {
                return new ExpNode(LEXICAL.LEX_MUL, param1, param2);
            }
            return GenAddExp(param1, param2);
        }
        IExpNode GenDivExp(IExpNode param1, IExpNode param2)
        {
            if (param2.Value != 0 && param1.Value % param2.Value == 0)
            {
                return new ExpNode(LEXICAL.LEX_DIV, param1, param2);
            }
            if (param1.Value != 0 && param2.Value % param1.Value == 0)
            {
                return new ExpNode(LEXICAL.LEX_DIV, param2, param1);
            }
            return GenAddExp(param1, param2);
        }
    }
}
