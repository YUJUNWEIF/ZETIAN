﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Combine
{
    public enum CombineState
    {
        Doing = 1,
        Failed = 2,
        Succeced = 3,
        TimeOut = 4,
    }
    public interface ICombineQuestionEvent
    {
        void CombineStateChanged(CombineState state);
    }
    class CombineExpr
    {
        public CombineExpr(int p1, int p2, int r, int op) { Param1 = p1; Param2 = p2; Result = r; Oper = op; }
        public int Param1 { get; private set; }
        public int Param2 { get; private set; }
        public int Result { get; private set; }
        public int Oper { get; private set; }
    }

    class CombineControl : Singleton<CombineControl>, IGameEvent
    {
        public LinkedList<ICombineQuestionEvent> m_combineEvent = new LinkedList<ICombineQuestionEvent>();
        public CombineState State
        {
            get { return m_state; }
            set
            {
                if (m_state != value)
                {
                    m_state = value;
                    foreach (ICombineQuestionEvent ev in m_combineEvent) { ev.CombineStateChanged(m_state); }
                }
            }
        }
        public IExpNode HeadNode { get; private set; }
        public float counter { get; private set; }
        public string Tips { get; private set; }
        private CombineState m_state = CombineState.Failed;
        private CombineSymbolInTools m_inTools;
        private CombineSymbolInAnswer m_inAnswer;        
        public void OnStartGame() 
        {
            m_inTools = new CombineSymbolInTools();
            m_inAnswer = new CombineSymbolInAnswer();
        }
        public void OnStopGame()
        {
            m_inTools = null;
            m_inAnswer = null;
        }
        public void AddCombineEvent(ICombineQuestionEvent ev) { if (m_combineEvent.Find(ev) == null) { m_combineEvent.AddLast(ev); } }
        public void RmvCombineEvent(ICombineQuestionEvent ev) { m_combineEvent.Remove(ev); }
        public void Start(int grade)
        {
            m_state = CombineState.Doing;
            counter = 30000;
            TimerManager.Instance.AddTimer(OnTimer, 1);

            if (UnityEngine.Random.Range(0, 2) == 0)
            { HeadNode = new CombineQuestion().GenWithArithmeticSeries(4); }
            else { HeadNode = new CombineQuestion().GenTwoGroup(); }

            Tips = ToString();
            ResetExp();
        }
        public void Stop() { TimerManager.Instance.RmvTimer(OnTimer); }
        public void Commit(IExpNode myParseTree)
        {
            if (m_state != CombineState.Doing) { return; }
            if (myParseTree.Value == HeadNode.Value)
            {
                //success
                m_state = CombineState.Succeced;
                foreach (ICombineQuestionEvent ev in m_combineEvent) { ev.CombineStateChanged(m_state); }
            }
            //else
            //{
            //    //failed
            //    m_state = CombineState.Failed;
            //    foreach (ICombineQuestionEvent ev in m_combineEvent) { ev.CombineStateChanged(m_state); }
            //}
        }
        public void ResetExp()
        {
            List<SSymbol> CombineNumbers = new List<SSymbol>();
            List<SSymbol> CombineTools = new List<SSymbol>();            
            foreach (char ch in Tips)
            {
                if (ch >= '0' && ch <= '9') { CombineNumbers.Add(new SSymbol(LEXICAL.LEX_CONST_INTEGER, new string(ch, 1))); }
                else
                {
                    switch (ch)
                    {
                        case '+': CombineTools.Add(new SSymbol(LEXICAL.LEX_ADD, new string(ch, 1))); break;
                        case '-': CombineTools.Add(new SSymbol(LEXICAL.LEX_SUB, new string(ch, 1))); break;
                        case '*': CombineTools.Add(new SSymbol(LEXICAL.LEX_MUL, new string(ch, 1))); break;
                        case '/': CombineTools.Add(new SSymbol(LEXICAL.LEX_DIV, new string(ch, 1))); break;
                        case '(': CombineTools.Add(new SSymbol(LEXICAL.LEX_SMALL_LEFT_BRACKET, new string(ch, 1))); break;
                        case ')': CombineTools.Add(new SSymbol(LEXICAL.LEX_SMALL_RIGHT_BRACKET, new string(ch, 1))); break;
                        default:
                            throw new InvalidExpOperatorException();
                    }
                }
            }
            CombineNumbers.Sort();
            CombineTools.Sort();
            CombineSymbolInTools.Instance.Reset(CombineTools);
            CombineSymbolInAnswer.Instance.Reset(CombineNumbers);
        }
        public override string ToString()
        {
            return GenExpString(HeadNode);
        }
        public void OnTimer()
        {
            counter -= 1;
            if (counter < 0)
            {
                TimerManager.Instance.RmvTimer(OnTimer);
                m_state = CombineState.TimeOut;
                foreach (ICombineQuestionEvent ev in m_combineEvent) { ev.CombineStateChanged(m_state); }
            }
        }
        string GenExpString(IExpNode no)
        {
            switch (no.NodeType)
            {
                case ExpElementType.Data: return no.Value.ToString();
                case ExpElementType.Exp:
                    {
                        ExpNode en = no as ExpNode;
                        string lstr = GenExpString(en.LeftNode);
                        string opstr = ExpOperator.ToString(en.Opr);
                        string rstr = GenExpString(en.RightNode);
                        string exp = lstr + opstr + rstr;
                        if (no.ParentNode != null)
                        {
                            if (no.ParentNode.LeftNode == this)//is left node
                            {
                                if (ExpOperator.Pl(en.Opr) < ExpOperator.Pl(no.ParentNode.Opr))
                                {
                                    return string.Format(@"({0})", exp);
                                }
                            }
                            else//is right node
                            {
                                if (ExpOperator.Pl(en.Opr) <= ExpOperator.Pl(no.ParentNode.Opr))
                                {
                                    return string.Format(@"({0})", exp);
                                }
                            }
                        }
                        return exp;
                    }
            }
            return null;
        }
    }
}

