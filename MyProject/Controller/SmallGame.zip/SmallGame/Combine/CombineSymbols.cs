﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Combine
{
    public enum ContainerType
    {
        InTools = 0,
        InAnswer = 1,
    }
    interface ICombineSymbol
    {
        void Insert(SSymbol symbol, int index);
        void Remove(SSymbol symbol);
        void Move(SSymbol symbol, int index);
        void Change(SSymbol os, SSymbol ns);
        void Swap(SSymbol a, SSymbol b);
    }
    class CombineSymbolImp
    {
        public CombineSymbolImp(List<SSymbol> symbols)
        {
            this.symbols = symbols;
        }
        public void Insert(SSymbol symbol, int index)
        {
            if (index < symbols.Count) { symbols.Insert(index, symbol); }
            else { symbols.Add(symbol); }
        }
        public void Remove(SSymbol symbol)
        {
            symbols.Remove(symbol);
        }
        public void Move(SSymbol symbol, int index)
        {
            int oldIndex = symbols.IndexOf(symbol);
            symbols.Insert(index, symbol);
            symbols.RemoveAt(oldIndex);
        }
        public void Change(SSymbol oldSymbol, SSymbol newSymbol)
        {
            int oldIndex = symbols.IndexOf(oldSymbol);
            symbols[oldIndex] = newSymbol;
        }
        public void Swap(SSymbol a, SSymbol b)
        {
            int oldIndex = symbols.IndexOf(a);
            int newIndex = symbols.IndexOf(b);
            symbols[oldIndex] = b;
            symbols[newIndex] = a;
        }
        public List<SSymbol> symbols { get; private set; }
    }
    class CombineSymbolInTools : Singleton<CombineSymbolInTools>, ICombineSymbol
    {
        private CombineSymbolImp m_combineSymbols;
        public List<SSymbol> CombineSymbols { get { return m_combineSymbols.symbols; } }
        public System.EventHandler<System.EventArgs> SymbolEvents;
        public void Reset(List<SSymbol> symbols)
        {
            m_combineSymbols = new CombineSymbolImp(symbols);
            FireSymbolEvent();
        }
        public void Insert(SSymbol symbol, int index)
        {
            m_combineSymbols.Insert(symbol, index);
            FireSymbolEvent();
        }
        public void Remove(SSymbol symbol)
        {
            m_combineSymbols.Remove(symbol);
            FireSymbolEvent();
        }
        public void Move(SSymbol symbol, int index)
        {
            m_combineSymbols.Move(symbol, index);
            FireSymbolEvent();
        }
        public void Change(SSymbol oldSymbol, SSymbol newSymbol)
        {
            m_combineSymbols.Change(oldSymbol, newSymbol);
            FireSymbolEvent();
        }
        public void Swap(SSymbol a, SSymbol b)
        {
            m_combineSymbols.Swap(a, b);
            FireSymbolEvent();
        }
        public void FireSymbolEvent()
        {
            if (SymbolEvents != null) { SymbolEvents(this, null); }
        }
    }

    class CombineSymbolInAnswer : Singleton<CombineSymbolInAnswer>, ICombineSymbol
    {
        private CombineSymbolImp m_combineSymbols;
        public List<SSymbol> CombineSymbols { get { return m_combineSymbols.symbols; } }
        public System.EventHandler<System.EventArgs> SymbolEvents;
        public void Reset(List<SSymbol> symbols)
        {
            m_combineSymbols = new CombineSymbolImp(symbols);
            FireSymbolEvent();
        }
        public void Insert(SSymbol symbol, int index)
        {
            m_combineSymbols.Insert(symbol, index);
            FireSymbolEvent();
        }
        public void Remove(SSymbol symbol)
        {
            m_combineSymbols.Remove(symbol);
            FireSymbolEvent();
        }
        public void Move(SSymbol symbol, int index)
        {
            m_combineSymbols.Move(symbol, index);
            FireSymbolEvent();
        }
        public void Change(SSymbol oldSymbol, SSymbol newSymbol)
        {
            m_combineSymbols.Change(oldSymbol, newSymbol);
            FireSymbolEvent();
        }
        public void Swap(SSymbol a, SSymbol b)
        {
            m_combineSymbols.Swap(a, b);
            FireSymbolEvent();
        }
        public void FireSymbolEvent()
        {
            if (SymbolEvents != null) { SymbolEvents(this, null); }
        }
        public void Commit()
        {
            CAlgorithmExpression expr = new CAlgorithmExpression(CombineSymbols);
            CombineControl.Instance.Commit(expr.Build());
        }
    }
}
