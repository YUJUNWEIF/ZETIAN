﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Combine
{
    interface IExpNode
    {
        ExpElementType NodeType { get; }
        ExpNode ParentNode { get; set; }
        int Value { get; }
    }

    class ValueNode : IExpNode
    {
        public ValueNode() { }
        public ValueNode(int value)
        {
            Value = value;
        }
        public void Build(SSymbol symbol)
        {
            switch (symbol.type)
            {
                case LEXICAL.LEX_CONST_INTEGER: Value = System.Convert.ToInt32(symbol.denote); break;
                default: throw new Exception("Invalid expression");
            }
        }
        public ExpElementType NodeType { get { return ExpElementType.Data; } }
        public ExpNode ParentNode { get; set; }
        public int Value { get; private set; }
    }

    class ExpNode : IExpNode
    {
        public ExpNode() { }
        public ExpNode(LEXICAL lex, IExpNode ln, IExpNode rn)
        {
            switch (lex)
            {
                case LEXICAL.LEX_ADD: Opr = ExpOperator.Add; break;
                case LEXICAL.LEX_SUB: Opr = ExpOperator.Sub; break;
                case LEXICAL.LEX_MUL: Opr = ExpOperator.Mul; break;
                case LEXICAL.LEX_DIV: Opr = ExpOperator.Div; break;
                default: throw new Exception("Invalid expression");
            }
            LeftNode = ln; LeftNode.ParentNode = this;
            RightNode = rn; LeftNode.ParentNode = this;
        }

        public void Build(SSymbol symbol)
        {
            switch (symbol.type)
            {
                case LEXICAL.LEX_ADD: Opr = ExpOperator.Add; break;
                case LEXICAL.LEX_SUB: Opr = ExpOperator.Sub; break;
                case LEXICAL.LEX_MUL: Opr = ExpOperator.Mul; break;
                case LEXICAL.LEX_DIV: Opr = ExpOperator.Div; break;
                default: throw new Exception("Invalid expression");
            }
        }
        public ExpElementType NodeType { get { return ExpElementType.Exp; } }
        public ExpNode ParentNode { get; set; }
        public int Value
        {
            get
            {
                switch (Opr)
                {
                    case ExpOperator.Add: return LeftNode.Value + RightNode.Value;
                    case ExpOperator.Sub: return LeftNode.Value - RightNode.Value;
                    case ExpOperator.Mul: return LeftNode.Value * RightNode.Value;
                    case ExpOperator.Div: return LeftNode.Value / RightNode.Value;
                }
                throw new Exception("Invalid expression");
            }
        }

        public int Opr { get; private set; }
        public IExpNode LeftNode { get { return m_leftNode; } set { m_leftNode = value; m_leftNode.ParentNode = this; } }
        public IExpNode RightNode { get { return m_rightNode; } set { m_rightNode = value; m_rightNode.ParentNode = this; } }
        private IExpNode m_leftNode;
        private IExpNode m_rightNode;
    }


    class CAlgorithmExpression
    {
        public CAlgorithmExpression(List<SSymbol> exp) { m_symbols = exp; }
        public IExpNode Build() { return m_expNodeHead = Expression(); }
        public void DestroyParseTree() { m_expNodeHead = null; }
        IExpNode Expression()	//<表达式>∷= <项>{(+|-) <项>}
        {
            IExpNode parentNode = _Term();
            SSymbol symbol;
            while ((symbol = NextSymbol()) != null)
            {
                if (symbol.type == LEXICAL.LEX_ADD || symbol.type == LEXICAL.LEX_SUB)
                {
                    ExpNode no = new ExpNode();
                    no.Build(symbol);
                    no.LeftNode = parentNode;
                    no.RightNode = _Term();
                    parentNode = no;
                }
                else
                {
                    BackSymbol();
                    break;
                }
            }
            return parentNode;
        }
        IExpNode _Term()			//<项>    ∷= <因子>{(*|/) <因子>}
        {
            IExpNode parentNode = _Factor();
            SSymbol symbol;
            while ((symbol = NextSymbol()) != null)
            {
                if (symbol.type == LEXICAL.LEX_MUL || symbol.type == LEXICAL.LEX_DIV)
                {
                    ExpNode no = new ExpNode();
                    no.Build(symbol);
                    no.LeftNode = parentNode;
                    no.RightNode = _Factor();
                    parentNode = no;
                }
                else
                {
                    BackSymbol();
                    break;
                }
            }
            return parentNode;
        }
        IExpNode _Factor()		//<因子>  ∷= id|num|‘(‘<表达式>‘)’
        {
            IExpNode parentNode = null;
            SSymbol symbol = NextSymbol();
            //if (symbol == null) { throw new Exception("Invalid expression"); }
            switch (symbol.type)
            {
                case LEXICAL.LEX_CONST_INTEGER:
                case LEXICAL.LEX_CONST_FLOAT:
                case LEXICAL.LEX_CONST_STRING:
                    ValueNode no = new ValueNode();
                    no.Build(symbol);
                    parentNode = no;
                    break;
                case LEXICAL.LEX_SMALL_LEFT_BRACKET:
                    PushSymbol(LEXICAL.LEX_SMALL_LEFT_BRACKET);
                    parentNode = Expression();
                    symbol = NextSymbol();
                    if (symbol == null || symbol.type != LEXICAL.LEX_SMALL_RIGHT_BRACKET || PopSymbol() != LEXICAL.LEX_SMALL_LEFT_BRACKET)
                    {
                        throw new Exception("Invalid expression");
                    }
                    break;
                default:
                    throw new Exception("Invalid expression");
            }
            return parentNode;
        }
        SSymbol NextSymbol()
        {
            if (++m_symbolIndex < m_symbols.Count) { return m_symbols[m_symbolIndex]; }
            return null;
        }
        void BackSymbol() { --m_symbolIndex; }
        SSymbol GetSymbol() { return m_symbols[m_symbolIndex]; }
        void PushSymbol(LEXICAL lex) { m_symbolstack.AddLast(lex); }
        LEXICAL PopSymbol()
        {
            if (m_symbolstack.Count > 0)
            {
                LEXICAL lex = m_symbolstack.Last.Value;
                m_symbolstack.RemoveLast();
                return lex;
            }
            return LEXICAL.LEX_NO_SYMBOL;
        }
        private IExpNode m_expNodeHead;
        private List<SSymbol> m_symbols = new List<SSymbol>();
        private LinkedList<LEXICAL> m_symbolstack = new LinkedList<LEXICAL>();
        private int m_symbolIndex = -1;
    };
}