﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Match
{
    public class MatchControl : Singleton<MatchControl>, IGameEvent
    {
        public enum State
        {
            Doing = 1,
            Succeced = 2,
            TimeOut = 3,
        }
        State m_state = State.Doing;
        MatchExprFromVary m_varier = new MatchExprFromVary();
        MatchExprFromAddRmv m_addrmv = new MatchExprFromAddRmv();
        MetaManager m_metaManager;

        public Util.Param1Actions<State> stateListener = new Util.Param1Actions<State>();
        public MatchExpr right { get; private set; }
        public MatchExpr wrong { get; private set; }
        public MatchExpr tryExpr { get; private set; }
        public State state
        {
            get { return m_state; }
            set { if (m_state != value) { stateListener.Fire(m_state = value); } }
        }
        public void OnStartGame() { m_metaManager = new MetaManager(); }
        public void OnStopGame() { m_metaManager = null; }
        public void GenFromVary()
        {
            state = State.Doing;
            right = null;
            wrong = null;
            MatchNumVary numVary = null;
            IVaryable vary = MetaManager.Instance.RandomFromVary();
            switch (UnityEngine.Random.Range(0, 3))
            {
                case MatchExprIndex.MatchParam1:
                    right = m_varier.UseAsFirstParam(vary as INumMeta);
                    numVary = vary.RandVary();
                    wrong = new MatchExpr(numVary.NewValue.Value, right.param2, right.result, right.oper);
                    break;
                case MatchExprIndex.MatchParam2:
                    right = m_varier.UseAsSecondParam(vary as INumMeta);
                    numVary = vary.RandVary();
                    wrong = new MatchExpr(right.param1, numVary.NewValue.Value, right.result, right.oper);
                    break;
                case MatchExprIndex.MatchResultHigh:
                    right = m_varier.UseAsResultHigh(vary as INumMeta);
                    if (right != null)
                    {
                        numVary = vary.RandVaryNotZero();
                        wrong = new MatchExpr(right.param1, right.param2, numVary.NewValue.Value * 10 + right.resultLow, right.oper);
                    }
                    break;
                case MatchExprIndex.MatchResultLow:
                    right = m_varier.UseAsResultLow(vary as INumMeta);
                    if (right != null)
                    {
                        numVary = vary.RandVary();
                        wrong = new MatchExpr(numVary.NewValue.Value, right.param2, right.resultHigh + numVary.NewValue.Value, right.oper);
                    }
                    break;
            }
            if (right == null || wrong == null)
            {
                right = m_varier.UseAsFirstParam(vary as INumMeta);
                numVary = vary.RandVary();
                wrong = new MatchExpr(numVary.NewValue.Value, right.param2, right.result, right.oper);
            }
        }
        public void GenFromAddRmv()
        {
            state = State.Doing;
            right = null;
            wrong = null;
            MatchNumAdd numAdd = null;
            MatchNumRmv numRmv = null;
            IAddable add = MetaManager.Instance.RandomFromAdd();
            IRmvable rmv = MetaManager.Instance.RandomFromRmv();
            if (UnityEngine.Random.Range(0, 1) == 0)
            {
                switch (UnityEngine.Random.Range(0, 6))
                {
                    case 0:
                        right = m_addrmv.UseAsParam1AndParam2(add as INumMeta, rmv as INumMeta);
                        numAdd = add.RandAdd();
                        numRmv = rmv.RandRmv();
                        wrong = new MatchExpr(numAdd.NewValue.Value, numRmv.NewValue.Value, right.result, right.oper);
                        break;
                    case 1:
                        right = m_addrmv.UseAsParam1AndResultHigh(add as INumMeta, rmv as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAdd();
                            numRmv = rmv.RandRmvNotZero();
                            wrong = new MatchExpr(numAdd.NewValue.Value, right.param2, (numRmv.NewValue.Value * 10) + right.resultLow, right.oper);
                        }
                        break;
                    case 2:
                        right = m_addrmv.UseAsParam1AndResultLow(add as INumMeta, rmv as INumMeta);
                        if (wrong != null)
                        {
                            numAdd = add.RandAdd();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(numAdd.NewValue.Value, right.param2, right.resultHigh+ numRmv.NewValue.Value, right.oper);
                        }
                        break;
                    case 3:
                        right = m_addrmv.UseAsParam2AndResultHigh(add as INumMeta, rmv as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAdd();
                            numRmv = rmv.RandRmvNotZero();
                            wrong = new MatchExpr(right.param1, numAdd.NewValue.Value, (numRmv.NewValue.Value * 10) + right.resultLow, right.oper);
                        }
                        break;
                    case 4:
                        right = m_addrmv.UseAsParam2AndResultLow(add as INumMeta, rmv as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAdd();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(right.param1, numAdd.NewValue.Value, right.resultHigh + numRmv.NewValue.Value, right.oper);
                        }
                        break;
                    case 5:
                        right = m_addrmv.UseAsResultHighAndLow(add as INumMeta, rmv as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAddNotZero();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(right.param1, right.param2, numAdd.NewValue.Value * 10 + numRmv.NewValue.Value, right.oper);
                        }
                        break;
                }
                if (right == null || wrong == null)
                {
                    right = m_addrmv.UseAsParam1AndParam2(add as INumMeta, rmv as INumMeta);
                    numAdd = add.RandAdd();
                    numRmv = rmv.RandRmv();
                    wrong = new MatchExpr(numAdd.NewValue.Value, numRmv.NewValue.Value, right.result, right.oper);
                }
            }
            else
            {
                switch (UnityEngine.Random.Range(0, 6))
                {
                    case 0:
                        right = m_addrmv.UseAsParam1AndParam2(rmv as INumMeta, add as INumMeta);
                        numAdd = add.RandAdd();
                        numRmv = rmv.RandRmv();
                        wrong = new MatchExpr(numRmv.NewValue.Value, numAdd.NewValue.Value, right.result, right.oper);
                        break;
                    case 1:
                        right = m_addrmv.UseAsParam1AndResultHigh(rmv as INumMeta, add as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAddNotZero();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(numRmv.NewValue.Value, right.param2, numAdd.NewValue.Value * 10 + right.resultLow, right.oper);
                        }
                        break;
                    case 2:
                        right = m_addrmv.UseAsParam1AndResultLow(rmv as INumMeta, add as INumMeta);
                        if (wrong != null)
                        {
                            numAdd = add.RandAdd();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(numRmv.NewValue.Value, right.param2, right.resultHigh + numAdd.NewValue.Value, right.oper);
                        }
                        break;
                    case 3:
                        right = m_addrmv.UseAsParam2AndResultHigh(rmv as INumMeta, add as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAddNotZero();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(right.param1, numRmv.NewValue.Value, numAdd.NewValue.Value * 10 + right.resultLow, right.oper);
                        }
                        break;
                    case 4:
                        right = m_addrmv.UseAsParam2AndResultLow(rmv as INumMeta, add as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAdd();
                            numRmv = rmv.RandRmv();
                            wrong = new MatchExpr(right.param1, numRmv.NewValue.Value, right.resultHigh + numAdd.NewValue.Value, right.oper);
                        }
                        break;
                    case 5:
                        right = m_addrmv.UseAsResultHighAndLow(rmv as INumMeta, add as INumMeta);
                        if (right != null)
                        {
                            numAdd = add.RandAddNotZero();
                            numRmv = rmv.RandRmvNotZero();
                            wrong = new MatchExpr(right.param1, right.param2, numRmv.NewValue.Value * 10 + numAdd.NewValue.Value, right.oper);
                        }
                        break;
                }
                if (right == null || wrong == null)
                {
                    numAdd = add.RandAdd();
                    numRmv = rmv.RandRmv();
                    right = m_addrmv.UseAsParam1AndParam2(rmv as INumMeta, add as INumMeta);
                    wrong = new MatchExpr(numRmv.NewValue.Value, numAdd.NewValue.Value, right.result, right.oper);
                }
            }
        }
        public void Answer(ExprLocation el, int value)
        {
            if (state != State.Doing) { return; }
            tryExpr = Substitute(wrong, el, value);
            if (tryExpr.TryCorrect()) { state = State.Succeced; }
        }
        public void Answer(ExprLocation elFrom, int vFrom, ExprLocation elTo, int vTo)
        {
            if (state != State.Doing) { return; }
            tryExpr = Substitute(wrong, elFrom, vFrom);
            tryExpr = Substitute(tryExpr, elTo, vTo); 
            if (tryExpr.TryCorrect()) { state = State.Succeced; }
        }
        public void InValidMatchMove()
        {
            //--Blood;
        }
        private static MatchExpr Substitute(MatchExpr old, ExprLocation el, int value)
        {
            MatchExpr tryExpr = null;
            switch (el)
            {
                case ExprLocation.Param1: tryExpr = new MatchExpr(value, old.param2, old.result, old.oper); break;
                case ExprLocation.Param2: tryExpr = new MatchExpr(old.param1, value, old.result, old.oper); break;
                case ExprLocation.ResultHigh: tryExpr = new MatchExpr(old.param1, old.param2, value * 10 + old.resultLow, old.oper); break;
                case ExprLocation.ResultLow: tryExpr = new MatchExpr(old.param1, old.param2, old.resultHigh + value, old.oper); break;
            }
            return tryExpr;
        }
    }
}


