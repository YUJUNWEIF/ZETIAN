﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Match
{
    class MatchCaculation
    {
        public MatchCaculation(MatchExpr right, int op) { Right = right; Oper = op; }
        public MatchCaculation(MatchExpr right, MatchExpr wrong, int op) { Right = right; Wrong = wrong; Oper = op; }
        public MatchExpr Right { get; private set; }
        public MatchExpr Wrong { get; set; }
        public int Oper { get; private set; }
    }
    public interface IMatchEletronicNumber
    {
        INumMeta OldValue { get; }
        INumMeta NewValue { get; }
    }
    public class MatchNumVary : IMatchEletronicNumber
    {
        public MatchNumVary(INumMeta ov, int from, int to, INumMeta nv) { OldValue = ov; FromIndex = from; ToIndex = to; NewValue = nv; }
        public INumMeta OldValue { get; private set; }
        public int FromIndex { get; private set; }
        public int ToIndex { get; private set; }
        public INumMeta NewValue { get; private set; }
    }
    public class MatchNumAdd : IMatchEletronicNumber
    {
        public MatchNumAdd(INumMeta ov, int add, INumMeta nv) { OldValue = ov; AddIndex = add; NewValue = nv; }
        public INumMeta OldValue { get; private set; }
        public int AddIndex { get; private set; }
        public INumMeta NewValue { get; private set; }
    }
    public class MatchNumRmv : IMatchEletronicNumber
    {
        public MatchNumRmv(INumMeta ov, int rmv, INumMeta nv) { OldValue = ov; RmvIndex = rmv; NewValue = nv; }
        public INumMeta OldValue { get; private set; }
        public int RmvIndex { get; private set; }
        public INumMeta NewValue { get; private set; }
    }
    public interface IAddable
    {
        MatchNumAdd Add(int index);
        MatchNumAdd RandAdd();
        MatchNumAdd RandAddNotZero();
        List<MatchNumAdd> Addables { get; }
    }
    public interface IRmvable
    {
        MatchNumRmv Rmv(int index);
        MatchNumRmv RandRmv();
        MatchNumRmv RandRmvNotZero();
        List<MatchNumRmv> Rmvables { get; }
    }
    public interface IVaryable
    {
        MatchNumVary Vary(int from, int to);
        MatchNumVary RandVary();
        MatchNumVary RandVaryNotZero();
        List<MatchNumVary> Varyables { get; }
    }
    public interface INumMeta
    {
        int Value { get; }
        string Mask { get; }
        void OnInitialize();
    }


    struct MatchExprIndex
    {
        public const int MatchParam1 = 0;
        public const int MatchParam2 = 1;
        public const int MatchResult = 2;
        public const int MatchResultHigh = 3;
        public const int MatchResultLow = 4;
    }

    class MetaManager : Singleton<MetaManager>
    {
        public MetaManager()
        {
            m_numMetas.Add(new ZeroMeta());
            m_numMetas.Add(new OneMeta());
            m_numMetas.Add(new TwoMeta());
            m_numMetas.Add(new ThreeMeta());
            m_numMetas.Add(new FourMeta());
            m_numMetas.Add(new FiveMeta());
            m_numMetas.Add(new SixMeta());
            m_numMetas.Add(new SevenMeta());
            m_numMetas.Add(new EightMeta());
            m_numMetas.Add(new NineMeta());
            foreach (INumMeta nm in m_numMetas)
            {
                nm.OnInitialize();
            }
        }
        public void RegisterAdd(IAddable add)
        {
            m_numAdds.Add(add);
        }
        public void RegisterRmv(IRmvable rmv)
        {
            m_numRmvs.Add(rmv);
        }
        public void RegisterVary(IVaryable vary)
        {
            m_numVaries.Add(vary);
        }
        public IAddable RandomFromAdd()
        {
            int addIndex = UnityEngine.Random.Range(0, m_numAdds.Count);
            return m_numAdds[addIndex];
        }
        public IRmvable RandomFromRmv()
        {
            int rmvIndex = UnityEngine.Random.Range(0, m_numRmvs.Count);
            return m_numRmvs[rmvIndex];
        }
        public IVaryable RandomFromVary()
        {
            int varyIndex = UnityEngine.Random.Range(0, m_numVaries.Count);
            return m_numVaries[varyIndex];
        }
        public INumMeta GetMeta(int num) { return m_numMetas[num]; }
        public T GetMeta<T>() where T : class, INumMeta
        {
            foreach (INumMeta mm in m_numMetas)
            {
                if (mm.GetType() == typeof(T)) { return mm as T; }
            }
            return null;
        }
        private List<INumMeta> m_numMetas = new List<INumMeta>();
        private List<IAddable> m_numAdds= new List<IAddable>();
        private List<IRmvable> m_numRmvs = new List<IRmvable>();
        private List<IVaryable> m_numVaries = new List<IVaryable>();
    }
}
