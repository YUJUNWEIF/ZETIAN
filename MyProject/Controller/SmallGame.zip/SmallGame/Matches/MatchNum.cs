﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Match
{
    class ZeroMeta : INumMeta, IVaryable, IAddable
    {
        public int Value { get { return 0; } }
        public string Mask { get { return "01111110"; } }
        public void OnInitialize()
        {
            Addables = new List<MatchNumAdd>();
            Addables.Add(new MatchNumAdd(this, 7, MetaManager.Instance.GetMeta<EightMeta>()));
            MetaManager.Instance.RegisterAdd(this);

            Varyables = new List<MatchNumVary>();
            Varyables.Add(new MatchNumVary(this, 3, 7, MetaManager.Instance.GetMeta<SixMeta>()));
            Varyables.Add(new MatchNumVary(this, 6, 7, MetaManager.Instance.GetMeta<NineMeta>()));
            MetaManager.Instance.RegisterVary(this);
        }
        public MatchNumAdd Add(int index)
        {
            foreach (MatchNumAdd add in Addables) { if (add.AddIndex == index) { return add; } }
            return null;
        }
        public MatchNumAdd RandAdd() { return Addables[0]; }
        public MatchNumAdd RandAddNotZero() { return Addables[0]; }
        public MatchNumVary Vary(int from, int to)
        {
            foreach (MatchNumVary vary in Varyables) { if (vary.FromIndex == from && vary.ToIndex == to) { return vary; } }
            return null;
        }
        public MatchNumVary RandVary() { return Varyables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumVary RandVaryNotZero() { return Varyables[UnityEngine.Random.Range(0, 2)]; }
        public List<MatchNumAdd> Addables { get; private set; }
        public List<MatchNumVary> Varyables { get; private set; }
    }

    class OneMeta : INumMeta, IAddable
    {
        public int Value { get { return 1; } }
        public string Mask { get { return "00011000"; } }
        public void OnInitialize()
        {
            Addables = new List<MatchNumAdd>();
            Addables.Add(new MatchNumAdd(this, 2, MetaManager.Instance.GetMeta<SevenMeta>()));
            MetaManager.Instance.RegisterAdd(this);
        }
        public MatchNumAdd Add(int index)
        {
            foreach (MatchNumAdd add in Addables) { if (add.AddIndex == index) { return add; } }
            return null;
        }
        public MatchNumAdd RandAdd() { return Addables[0]; }
        public MatchNumAdd RandAddNotZero() { return Addables[0]; }
        public List<MatchNumAdd> Addables { get; private set; }
    }

    class TwoMeta : INumMeta, IVaryable
    {
        public int Value { get { return 2; } }
        public string Mask { get { return "00110111"; } }
        public void OnInitialize()
        {            
            Varyables = new List<MatchNumVary>();
            Varyables.Add(new MatchNumVary(this, 6, 4, MetaManager.Instance.GetMeta<ThreeMeta>()));
            MetaManager.Instance.RegisterVary(this);
        }
        public MatchNumVary Vary(int from, int to)
        {
            foreach (MatchNumVary vary in Varyables) { if (vary.FromIndex == from && vary.ToIndex == to) { return vary; } }
            return null;
        }
        public MatchNumVary RandVary() { return Varyables[0]; }
        public MatchNumVary RandVaryNotZero() { return Varyables[0]; }
        public List<MatchNumVary> Varyables { get; private set; }
    }
    class ThreeMeta : INumMeta, IAddable, IVaryable
    {
        public int Value { get { return 3; } }
        public string Mask { get { return "00111101"; } }
        public void OnInitialize()
        {
            Addables = new List<MatchNumAdd>();
            Addables.Add(new MatchNumAdd(this, 1, MetaManager.Instance.GetMeta<NineMeta>()));
            MetaManager.Instance.RegisterAdd(this);

            Varyables = new List<MatchNumVary>();
            Varyables.Add(new MatchNumVary(this, 4, 6, MetaManager.Instance.GetMeta<TwoMeta>()));
            Varyables.Add(new MatchNumVary(this, 3, 1, MetaManager.Instance.GetMeta<FiveMeta>()));
            MetaManager.Instance.RegisterVary(this);
        }
        public MatchNumAdd Add(int index)
        {
            foreach (MatchNumAdd add in Addables) { if (add.AddIndex == index) { return add; } }
            return null;
        }
        public MatchNumAdd RandAdd() { return Addables[0]; }
        public MatchNumAdd RandAddNotZero() { return Addables[0]; }
        public MatchNumVary Vary(int from, int to)
        {
            foreach (MatchNumVary vary in Varyables) { if (vary.FromIndex == from && vary.ToIndex == to) { return vary; } }
            return null;
        }
        public MatchNumVary RandVary() { return Varyables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumVary RandVaryNotZero() { return Varyables[UnityEngine.Random.Range(0, 2)]; }
        public List<MatchNumAdd> Addables { get; private set; }
        public List<MatchNumVary> Varyables { get; private set; }
    }
    class FourMeta : INumMeta
    {
        public int Value { get { return 4; } }
        public string Mask { get { return "01011001"; } }
        public void OnInitialize() { }
    }
    class FiveMeta : INumMeta, IAddable, IVaryable
    {
        public int Value { get { return 5; } }
        public string Mask { get { return "01101101"; } }
        public void OnInitialize()
        {
            Addables = new List<MatchNumAdd>();
            Addables.Add(new MatchNumAdd(this, 3, MetaManager.Instance.GetMeta<NineMeta>()));
            Addables.Add(new MatchNumAdd(this, 6, MetaManager.Instance.GetMeta<SixMeta>()));
            MetaManager.Instance.RegisterAdd(this);

            Varyables = new List<MatchNumVary>();
            Varyables.Add(new MatchNumVary(this, 1, 3, MetaManager.Instance.GetMeta<ThreeMeta>()));
            MetaManager.Instance.RegisterVary(this);
        }
        public MatchNumAdd Add(int index)
        {
            foreach (MatchNumAdd add in Addables) { if (add.AddIndex == index) { return add; } }
            return null;
        }
        public MatchNumAdd RandAdd() { return Addables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumAdd RandAddNotZero() { return Addables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumVary Vary(int from, int to)
        {
            foreach (MatchNumVary vary in Varyables) { if (vary.FromIndex == from && vary.ToIndex == to) { return vary; } }
            return null;
        }
        public MatchNumVary RandVary() { return Varyables[0]; }
        public MatchNumVary RandVaryNotZero() { return Varyables[0]; }
        public List<MatchNumAdd> Addables { get; private set; }
        public List<MatchNumVary> Varyables { get; private set; }
    }
    class SixMeta : INumMeta, IAddable, IRmvable, IVaryable
    {
        public int Value { get { return 6; } }
        public string Mask { get { return "01101111"; } }
        public void OnInitialize()
        {
            Addables = new List<MatchNumAdd>();
            Addables.Add(new MatchNumAdd(this, 3, MetaManager.Instance.GetMeta<EightMeta>()));
            MetaManager.Instance.RegisterAdd(this);

            Rmvables = new List<MatchNumRmv>();
            Rmvables.Add(new MatchNumRmv(this, 6, MetaManager.Instance.GetMeta<FiveMeta>()));
            MetaManager.Instance.RegisterRmv(this);

            Varyables = new List<MatchNumVary>();
            Varyables.Add(new MatchNumVary(this, 6, 3, MetaManager.Instance.GetMeta<NineMeta>()));
            Varyables.Add(new MatchNumVary(this, 7, 3, MetaManager.Instance.GetMeta<ZeroMeta>()));
            MetaManager.Instance.RegisterVary(this);
        }
        public MatchNumAdd Add(int index)
        {
            foreach (MatchNumAdd add in Addables) { if (add.AddIndex == index) { return add; } }
            return null;
        }
        public MatchNumAdd RandAdd() { return Addables[0]; }
        public MatchNumAdd RandAddNotZero() { return Addables[0]; }
        public MatchNumRmv Rmv(int index)
        {
            foreach (MatchNumRmv rmv in Rmvables) { if (rmv.RmvIndex == index) { return rmv; } }
            return null;
        }
        public MatchNumRmv RandRmv() { return Rmvables[0]; }
        public MatchNumRmv RandRmvNotZero() { return Rmvables[0]; }
        public MatchNumVary Vary(int from, int to)
        {
            foreach (MatchNumVary vary in Varyables) { if (vary.FromIndex == from && vary.ToIndex == to) { return vary; } }
            return null;
        }
        public MatchNumVary RandVary() { return Varyables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumVary RandVaryNotZero() { return Varyables[0]; }
        public List<MatchNumAdd> Addables { get; private set; }
        public List<MatchNumRmv> Rmvables { get; private set; }
        public List<MatchNumVary> Varyables { get; private set; }
    }
    class SevenMeta : INumMeta, IRmvable
    {
        public int Value { get { return 7; } }
        public string Mask { get { return "00111000"; } }
        public void OnInitialize()
        {
            Rmvables = new List<MatchNumRmv>();
            Rmvables.Add(new MatchNumRmv(this, 2, MetaManager.Instance.GetMeta<OneMeta>()));
            MetaManager.Instance.RegisterRmv(this);
        }
        public MatchNumRmv Rmv(int index)
        {
            foreach (MatchNumRmv rmv in Rmvables) { if (rmv.RmvIndex == index) { return rmv; } }
            return null;
        }
        public MatchNumRmv RandRmv() { return Rmvables[0]; }
        public MatchNumRmv RandRmvNotZero() { return Rmvables[0]; }
        public List<MatchNumRmv> Rmvables { get; private set; }
    }
    class EightMeta : INumMeta, IRmvable
    {
        public int Value { get { return 8; } }
        public string Mask { get { return "01111111"; } }
        public void OnInitialize()
        {
            Rmvables = new List<MatchNumRmv>();
            Rmvables.Add(new MatchNumRmv(this, 3, MetaManager.Instance.GetMeta<SixMeta>()));
            Rmvables.Add(new MatchNumRmv(this, 6, MetaManager.Instance.GetMeta<NineMeta>()));
            Rmvables.Add(new MatchNumRmv(this, 7, MetaManager.Instance.GetMeta<ZeroMeta>()));
            MetaManager.Instance.RegisterRmv(this);
        }
        public MatchNumRmv Rmv(int index)
        {
            foreach (MatchNumRmv rmv in Rmvables) { if (rmv.RmvIndex == index) { return rmv; } }
            return null;
        }
        public MatchNumRmv RandRmv() { return Rmvables[UnityEngine.Random.Range(0, 3)]; }
        public MatchNumRmv RandRmvNotZero() { return Rmvables[UnityEngine.Random.Range(0, 2)]; }
        public List<MatchNumRmv> Rmvables { get; private set; }
    }
    class NineMeta : INumMeta, IAddable, IRmvable, IVaryable
    {
        public int Value { get { return 9; } }
        public string Mask { get { return "01111101"; } }
        public void OnInitialize()
        {
            Addables = new List<MatchNumAdd>();
            Addables.Add(new MatchNumAdd(this, 6, MetaManager.Instance.GetMeta<EightMeta>()));
            MetaManager.Instance.RegisterAdd(this);

            Rmvables = new List<MatchNumRmv>();
            Rmvables.Add(new MatchNumRmv(this, 1, MetaManager.Instance.GetMeta<ThreeMeta>()));
            Rmvables.Add(new MatchNumRmv(this, 3, MetaManager.Instance.GetMeta<FiveMeta>()));
            MetaManager.Instance.RegisterRmv(this);

            Varyables = new List<MatchNumVary>();
            Varyables.Add(new MatchNumVary(this, 3, 6, MetaManager.Instance.GetMeta<SixMeta>()));
            Varyables.Add(new MatchNumVary(this, 7, 6, MetaManager.Instance.GetMeta<ZeroMeta>()));
            MetaManager.Instance.RegisterVary(this);
        }
        public MatchNumAdd Add(int index)
        {
            foreach (MatchNumAdd add in Addables) { if (add.AddIndex == index) { return add; } }
            return null;
        }
        public MatchNumAdd RandAdd() { return Addables[0]; }
        public MatchNumAdd RandAddNotZero() { return Addables[0]; }
        public MatchNumRmv Rmv(int index)
        {
            foreach (MatchNumRmv rmv in Rmvables) { if (rmv.RmvIndex == index) { return rmv; } }
            return null;
        }
        public MatchNumRmv RandRmv() { return Rmvables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumRmv RandRmvNotZero() { return Rmvables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumVary Vary(int from, int to)
        {
            foreach (MatchNumVary vary in Varyables) { if (vary.FromIndex == from && vary.ToIndex == to) { return vary; } }
            return null;
        }
        public MatchNumVary RandVary() { return Varyables[UnityEngine.Random.Range(0, 2)]; }
        public MatchNumVary RandVaryNotZero() { return Varyables[0]; }
        public List<MatchNumAdd> Addables { get; private set; }
        public List<MatchNumRmv> Rmvables { get; private set; }
        public List<MatchNumVary> Varyables { get; private set; }
    }
}
