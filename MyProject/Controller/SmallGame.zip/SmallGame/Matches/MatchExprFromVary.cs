﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Match
{
	class MatchExprFromVary
	{
        public MatchExprFromVary()
        {
            for (int index = 0; index <= 9; ++index) { option.Add(index); }
            for (int index = 1; index <= 3; ++index) { DivParam2.Add(index); }
        }
        //public MatchExpr GenFromVary()
        //{
        //    IVaryable vary = MetaManager.Instance.RandomFromVary();
        //    INumMeta num = vary as INumMeta;
        //    int loc = UnityEngine.Random.Range(0, 3);
        //    switch (loc)
        //    {
        //        case MatchExprIndex.MatchParam1: return UseAsFirstParam(num); 
        //        case MatchExprIndex.MatchParam2: return UseAsSecondParam(num);
        //        case MatchExprIndex.MatchResultHigh: return UseAsResultHigh(num);
        //        case MatchExprIndex.MatchResultLow: return UseAsResultLow(num);
        //    }
        //    return null;
        //}
        public MatchExpr UseAsFirstParam(INumMeta num)
        {
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    {                        
                        int param2 = UnityEngine.Random.Range(0, 10);
                        return new MatchExpr(num.Value, param2, num.Value + param2, op);
                    }
                case ExpOperator.Sub:
                    {
                        int param2 = UnityEngine.Random.Range(0, num.Value + 1);
                        return new MatchExpr(num.Value, param2, num.Value - param2, op);
                    }
                case ExpOperator.Mul:
                    {
                        int param2 = UnityEngine.Random.Range(0, 10);
                        return new MatchExpr(num.Value, param2, num.Value * param2, op);
                    }
                case ExpOperator.Div:                   
                    for (int chances = DivParam2.Count; chances > 0; --chances)
                    {
                        int index = UnityEngine.Random.Range(0, chances);
                        int param2 = DivParam2[index];
                        int result = num.Value / param2;
                        if (result * param2 == num.Value)
                        {
                            return new MatchExpr(num.Value, param2, result, op);
                        }
                        else
                        {
                            DivParam2[index] = DivParam2[chances - 1];
                            DivParam2[chances - 1] = param2;
                        }
                    }
                    return null;
            }
            return null;
        }
        public MatchExpr UseAsSecondParam(INumMeta num)
        {
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    {
                        int param1 = UnityEngine.Random.Range(0, 10);
                        return new MatchExpr(param1, num.Value, param1 + num.Value, op);
                    }
                case ExpOperator.Sub:
                    {
                        int param1 = UnityEngine.Random.Range(num.Value, 10);
                        return new MatchExpr(param1, num.Value, param1 - num.Value, op);
                    }
                case ExpOperator.Mul:
                    {
                        int param1 = UnityEngine.Random.Range(0, 10);
                        return new MatchExpr(param1, num.Value, param1 * num.Value, op);
                    }
                case ExpOperator.Div:
                    if (num.Value != 0)
                    {
                        int maxResult = 9 / num.Value;
                        int result = UnityEngine.Random.Range(0, maxResult + 1);
                        return new MatchExpr(num.Value * result, num.Value, result, op);
                    }
                    else
                    {
                        int param1 = UnityEngine.Random.Range(0, 10);
                        return new MatchExpr(param1, num.Value, param1 + num.Value, ExpOperator.Add);
                    }
            }
            return null;
        }
        public MatchExpr UseAsResultHigh(INumMeta num)
        {
            if (num.Value == 0) { return null; }

            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    if (num.Value != 1) { return null; }
                    {
                        int result = 10 + UnityEngine.Random.Range(0, 9);
                        int param1 = UnityEngine.Random.Range(result - 9, 10);
                        return new MatchExpr(param1, result - param1, result, op);
                    }
                case ExpOperator.Sub: return null;
                case ExpOperator.Mul: 
                    for (int chances = option.Count; chances > 0; --chances)
                    {
                        int index = UnityEngine.Random.Range(0, chances);
                        MatchExpr right = InverseCaculateP1AndP2WithMul(num.Value * 10 + option[index]);
                        if (right != null) { return right; }
                        int tmp = option[index];
                        option[index] = option[chances - 1];
                        option[chances - 1] = tmp;
                    }
                    return null;
                case ExpOperator.Div: return null;
            }
            return null;
        }
        public MatchExpr UseAsResultLow(INumMeta num)
        {
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    {
                        int result = 10 + num.Value;
                        int param1 = UnityEngine.Random.Range(result, 10);
                        return new MatchExpr(param1, result - param1, result, op);
                    }
                case ExpOperator.Sub:
                    {
                        int param1 = UnityEngine.Random.Range(num.Value, 10);
                        return new MatchExpr(param1, param1 - num.Value, num.Value, op);
                    }
                case ExpOperator.Mul:
                    for (int chances = option.Count; chances > 0; --chances)
                    {
                        int index = UnityEngine.Random.Range(0, chances);
                        MatchExpr right = InverseCaculateP1AndP2WithMul(option[index] * 10 + num.Value);
                        if (right != null) { return right; }
                        int tmp = option[index];
                        option[index] = option[chances - 1];
                        option[chances - 1] = tmp;
                    }
                    return null;
                case ExpOperator.Div:
                    if (num.Value == 0)
                    {
                        return new MatchExpr(0, UnityEngine.Random.Range(1, 10), 0, op);
                    }
                    int maxParam2 = (9 + num.Value - 1)/ num.Value;
                    int param2 = UnityEngine.Random.Range(1, maxParam2);
                    return new MatchExpr(num.Value * param2, param2, num.Value, op);
            }
            return null;
        }
        MatchExpr InverseCaculateP1AndP2WithMul(int result)
        {
            if (result == 0)
            {
                return new MatchExpr(0, UnityEngine.Random.Range(0, 10), result, ExpOperator.Mul);
            }

            int minParam2 = (result + 8) / 9;
            int maxParam2 = (int)UnityEngine.Mathf.Sqrt(result + 1);
            for (int param2 = maxParam2; param2 >= minParam2; --param2)
            {
                int param1 = result / param2;
                if (param1 < 10 && param2 < 10 && param1 * param2 == result)
                {
                    if (UnityEngine.Random.Range(0, 2) == 0) return new MatchExpr(param1, param2, result, ExpOperator.Mul);
                    return new MatchExpr(param2, param1, result, ExpOperator.Mul);
                }
            }
            return null;
        }
        private List<int> option = new List<int>();
        private List<int> DivParam2 = new List<int>();
	}
}
