﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Match
{
    class MatchExprFromAddRmv
	{
        public MatchExpr UseAsParam1AndParam2(INumMeta p1, INumMeta p2)
        {
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    return new MatchExpr(p1.Value, p2.Value, p1.Value + p2.Value, op);
                case ExpOperator.Sub: 
                    if (p1.Value >= p2.Value)
                    {
                        return new MatchExpr(p1.Value, p2.Value, p1.Value - p2.Value, op);
                    }
                    return new MatchExpr(p1.Value, p2.Value, p1.Value + p2.Value, ExpOperator.Add);
                case ExpOperator.Mul:
                    return new MatchExpr(p1.Value, p2.Value, p1.Value * p2.Value, op);
                case ExpOperator.Div: 
                    if (p2.Value != 0 && p1.Value % p2.Value == 0)
                    {
                        return new MatchExpr(p1.Value, p2.Value, p1.Value / p2.Value, op);
                    }
                    return new MatchExpr(p1.Value, p2.Value, p1.Value * p2.Value, ExpOperator.Mul);
                    
            }
            return null;
        }
        public MatchExpr UseAsParam1AndResultHigh(INumMeta p1, INumMeta r)
        {
            if (r.Value == 0) { return null; }

            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    {
                        if (r.Value == 1)
                        {
                            int maxParam2 = p1.Value + 9 - r.Value * 10;
                            if (maxParam2 < 0) { return null; }
                            int param2 = UnityEngine.Random.Range(0, maxParam2);
                            return new MatchExpr(p1.Value, param2, p1.Value + param2, op);
                        }
                        return null;
                    }
                case ExpOperator.Mul:
                    {
                        if (p1.Value == 0) return null;
                        int minParam2 = (r.Value * 10 + p1.Value - 1) / p1.Value;
                        int maxParam2 = (r.Value * 10 + 9 + p1.Value - 1) / p1.Value;
                        if (minParam2 > 9) return null;
                        int param2 = UnityEngine.Random.Range(minParam2, UnityEngine.Mathf.Min(9, maxParam2));
                        return new MatchExpr(p1.Value, param2, p1.Value * param2, op);
                    }
                case ExpOperator.Sub:
                case ExpOperator.Div: return null;
            }
            return null;
        }
        MatchExpr CaculateAddWithParam1AndResultLow(INumMeta p1, INumMeta r)
        {
            if (r.Value >= p1.Value)
            {
                return new MatchExpr(p1.Value, r.Value - p1.Value, r.Value, ExpOperator.Add);
            }
            else
            {
                int result = 10 + r.Value;
                return new MatchExpr(p1.Value, result - p1.Value, result, ExpOperator.Add);
            }
        }
        public MatchExpr UseAsParam1AndResultLow(INumMeta p1, INumMeta r)
        {
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add: return CaculateAddWithParam1AndResultLow(p1, r);
                case ExpOperator.Sub:
                    if (p1.Value >= r.Value) 
                    {
                        return new MatchExpr(p1.Value, p1.Value - r.Value, r.Value, op); 
                    }
                    return new MatchExpr(p1.Value, r.Value - p1.Value, r.Value, ExpOperator.Add);
                case ExpOperator.Mul:
                    if (p1.Value == 0)
                        return new MatchExpr(p1.Value, r.Value, r.Value, ExpOperator.Add);
                    for (int index = 0; index < 9; ++index)
                    {
                        int result = index * 10 + r.Value;
                        int param2 = result / p1.Value;
                        if (param2 > 9) { break; }
                        if (param2 * p1.Value == r.Value) { return new MatchExpr(p1.Value, param2, result, op); }
                    }
                    return CaculateAddWithParam1AndResultLow(p1, r);
                case ExpOperator.Div:
                    {
                        int param2 = p1.Value / r.Value;
                        if (param2 * r.Value == p1.Value)
                        {
                            return new MatchExpr(p1.Value, param2, r.Value, op);
                        }
                    }
                    return CaculateAddWithParam1AndResultLow(p1, r);
            }
            return null;
        }
        public MatchExpr UseAsParam2AndResultHigh(INumMeta p2, INumMeta r)
        {
            if (r.Value == 0) { return null; }

            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    {
                        if (r.Value == 1)
                        {
                            int maxParam1 = p2.Value + 9 - r.Value * 10;
                            if (maxParam1 < 0) { return null; }
                            int param1 = UnityEngine.Random.Range(0, maxParam1);
                            return new MatchExpr(param1, p2.Value, param1 + p2.Value, op);
                        }
                        return null;
                    }
                case ExpOperator.Mul:
                    {
                        if (p2.Value == 0) return null;
                        int minParam1 = (r.Value * 10 + p2.Value - 1) / p2.Value;
                        int maxParam1 = (r.Value * 10 + 9 + p2.Value - 1) / p2.Value;
                        if (minParam1 > 9) return null;
                        int param1 = UnityEngine.Random.Range(minParam1, UnityEngine.Mathf.Min(9, maxParam1));
                        return new MatchExpr(param1, p2.Value, param1 * p2.Value, op);
                    }
                case ExpOperator.Sub:
                case ExpOperator.Div: return null;
            }
            return null;
        }
        public MatchExpr CaculateAddWithParam2AndResultLow(INumMeta p2, INumMeta r)
        {
            if (r.Value >= p2.Value)
            {
                return new MatchExpr(r.Value - p2.Value, p2.Value, r.Value, ExpOperator.Add);
            }
            else
            {
                int result = 10 + r.Value;
                return new MatchExpr(result - p2.Value, p2.Value, result, ExpOperator.Add);
            }
        }
        public MatchExpr UseAsParam2AndResultLow(INumMeta p2, INumMeta r)
        {
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add: return CaculateAddWithParam2AndResultLow(p2, r);
                case ExpOperator.Sub:
                    if (p2.Value + r.Value <= 9) { return new MatchExpr(p2.Value + r.Value, p2.Value, r.Value, op); }
                    return CaculateAddWithParam2AndResultLow(p2, r);
                case ExpOperator.Mul:
                    if (p2.Value == 0) return new MatchExpr(r.Value, p2.Value, r.Value, ExpOperator.Add);
                    for (int index = 0; index < 9; ++index)
                    {
                        int result = index * 10 + r.Value;
                        int param1 = result / p2.Value;
                        if (param1 > 9) { break; }
                        if (param1 * p2.Value == r.Value) { return new MatchExpr(param1, p2.Value, result, op); }
                    }
                    return CaculateAddWithParam2AndResultLow(p2, r);
                case ExpOperator.Div:
                    {
                        int param1 = p2.Value * r.Value;
                        if (param1 < 10) { return new MatchExpr(param1, p2.Value, r.Value, op); }
                    }
                    return CaculateAddWithParam2AndResultLow(p2, r);
            }
            return null;
        }
        public MatchExpr UseAsResultHighAndLow(INumMeta rh, INumMeta rl)
        {
            if (rh.Value == 0) return null;
            
            int result = rh.Value * 10 + rl.Value;
            int op = UnityEngine.Random.Range(0, 4);
            switch (op)
            {
                case ExpOperator.Add:
                    {
                        if (result <= 18)
                        {
                            int minParam1 = UnityEngine.Mathf.Max(result - 9, 0);
                            int maxParam1 = UnityEngine.Mathf.Min(9, result);
                            int param1 = UnityEngine.Random.Range(minParam1, maxParam1 + 1);
                            return new MatchExpr(param1, result - param1, result, op);
                        }
                        return null;
                    }
                case ExpOperator.Sub: return null;
                case ExpOperator.Mul:
                        int minParam2 = (result + 8) / 9;
                        int maxParam2 = (int)UnityEngine.Mathf.Sqrt(result + 1);
                        List<int> op2 = new List<int>();
                        for (int index = minParam2; index <= maxParam2; ++index) { op2.Add(index); }
                        for (int chances = op2.Count; chances > 0; --chances)
                        {
                            int index = UnityEngine.Random.Range(0, chances);
                            if (result % op2[index] == 0)
                            {
                                if (UnityEngine.Random.Range(0, 2) == 0)
                                {
                                    return new MatchExpr(op2[index], result / op2[index], result, op);
                                }
                                return new MatchExpr(result / op2[index], op2[index], result, op);
                            }
                            int tmp = op2[index];
                            op2[index] = op2[chances - 1];
                            op2[chances - 1] = tmp;
                        }
                    return null;
                case ExpOperator.Div: return null;
            }
            return null;
        }
	}
}
