﻿using System;
using System.Collections.Generic;

namespace geniusbaby.Match
{
    public class MatchParam1
    {
        public MatchParam1(int v) { m_param1 = MetaManager.Instance.GetMeta(v); }
        public int Value
        {
            get { return m_param1.Value; }
            set { m_param1 = MetaManager.Instance.GetMeta(Value); }
        }
        private INumMeta m_param1;
    }

    public class MatchParam2
    {
        public MatchParam2(int v) { m_param1 = MetaManager.Instance.GetMeta(v); }
        public int Value
        {
            get { return m_param1.Value; }
            set { m_param1 = MetaManager.Instance.GetMeta(Value); }
        }
        private INumMeta m_param1;
    }
    public class MatchResult
    {
        public MatchResult(int v) { Value = v; }
        public int Value 
        {
            get { return (m_highSection != null ? m_highSection.Value * 10 : 0) + m_lowSection.Value; }
            set
            {
                int high = value / 10;
                int low = value % 10;
                if (high > 0) { m_highSection = MetaManager.Instance.GetMeta(high); }
                m_lowSection = MetaManager.Instance.GetMeta(low);
            }
        }
        public INumMeta High { get { return m_highSection; } }
        public INumMeta Low { get { return m_lowSection; } }
        private INumMeta m_highSection;
        private INumMeta m_lowSection;
    }

    public class MatchExpr
    {
        public MatchExpr(int p1, int p2, int r, int op)
        {
            param1 = p1;
            param2 = p2;
            result = r;
            oper = op;
        }
        public int param1 { get; private set; }
        public int param2 { get; private set; }
        public int result { get; private set; }
        public int resultHigh { get { return (result / 10) * 10; } }
        public int resultLow { get { return result % 10; } }
        public int oper { get; private set; }
        public bool TryCorrect()
        {
            switch (oper)
            {
                case ExpOperator.Add: return param1 + param2 == result;
                case ExpOperator.Sub: return param1 - param2 == result;
                case ExpOperator.Mul: return param1 * param2 == result;
                case ExpOperator.Div: return (param2 != 0) && (param1 / param2 == result);
            }
            return false;
        }
    }
    public enum ExprLocation
    {
        Param1 = 0,
        Param2 = 1,
        ResultHigh = 2,
        ResultLow = 3,
    }
}
