﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace geniusbaby
{
    class InvalidExpOperatorException : System.Exception { }

    public enum ExpElementType
    {
        Data = 0,
        Exp = 1,
        Empty = 2,
    }

    struct ExpOperator
    {
        public const int Add = 0;
        public const int Sub = 1;
        public const int Mul = 2;
        public const int Div = 3;
        public enum PriorityLevel
        {
            AddSub = 0,
            MulDiv = 1,
        }
        public static PriorityLevel Pl(int ap)
        {
            if (ap >= 0 && ap < 2) return PriorityLevel.AddSub;
            if (ap >= 2 && ap < 4) return PriorityLevel.MulDiv;
            throw new InvalidExpOperatorException();
        }
        public static string ToString(int op)
        {
            switch (op)
            {
                case Add: return "+";
                case Sub: return "-";
                case Mul: return "*";
                case Div: return "/";
            }
            throw new InvalidExpOperatorException();
        }
    }
}
