﻿using UnityEngine;
using System.Collections.Generic;

namespace geniusbaby.smallgame
{
	public class AwardControl : Singleton<AwardControl>, IGameEvent
    {   
        public float duration { get; private set; }
        public Util.ParamActions onStop = new Util.ParamActions();
        public int expGet { get; private set; }
        public int moneyGet { get; private set; }
        public AwardReceiver receiver { get; private set; }
        public AwardThrower thrower { get; private set; }
        public void OnStartGame() { }
        public void OnStopGame() { }
        public void Start()
        {
            //duration = Time.time + 100000;
            //expGet = 0;
            //moneyGet = 0;
            //TimerManager.Instance.AddTimer(OnTimer, 1f);

            //var player = PlayerModule.Instance.player;

            //receiver = IGameObj.Load<AwardReceiver>(new EntityId(ObjType.Player, 0), player.moduleId);
            ////receiver.ChangeEquipsSync(player.head);
            ////receiver.ChangeEquipsSync(player.body);
            ////receiver.ChangeEquipsSync(player.weapon);
            //receiver.property.player = pps.proto.ProtoUtil.ToServer(player);
            //receiver.equipGroup.equip = new int[] { 0, player.head, player.body, player.weapon };
            //SceneManager.Instance.AddEntity(receiver, receiver.transport);

            //thrower = IGameObj.Load<AwardThrower>(new EntityId(ObjType.Monster, 0), 1);
            //SceneManager.Instance.AddEntity(thrower, thrower.m);
            //thrower.StartWork();
        }
        public void Stop()
        {
            thrower.StopWork();
            TimerManager.Instance.RmvTimer(OnTimer);
        }
        public void OnTimer()
        {
            if (Time.time > duration)
            {
                Stop();
                onStop.Fire();
            }
        }
        public void Collect(AwardObj obj)
        {
            expGet += 10;
            moneyGet += 1;
            OutOfView(obj.entityId);
        }
        public void OutOfView(EntityId entityId)
        {
            SceneManager.Instance.RmvEntity(entityId);
        }
	}
}
