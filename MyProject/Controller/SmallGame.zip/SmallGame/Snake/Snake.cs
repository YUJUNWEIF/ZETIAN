﻿using UnityEngine;
using System.Collections.Generic;

namespace geniusbaby.smallgame
{
    public class Snake : Singleton<Snake>, IGameEvent
    {
        public const int Row = 8;
        public const int Col = 8;
        public LinkedList<Grid> snakeNodes = new LinkedList<Grid>();
        public LinkedList<Grid> apples = new LinkedList<Grid>();
        public Util.ParamActions onDie = new Util.ParamActions();
        FingerGestures.SwipeDirection m_direction;
        public void OnStartGame() { }
        public void OnStopGame() { }
        public void Start()
        {
            TimerManager.Instance.AddTimer(OnTimer, 0.5f);
            m_direction = (FingerGestures.SwipeDirection) (1 << UnityEngine.Random.Range(0, 4));
            switch (m_direction)
            {
                case FingerGestures.SwipeDirection.Left:
                    for (int index = 2; index >= -2; --index)
                    {
                        AddSnakeNode(new Grid(index, 0));
                    }
                    break;
                case FingerGestures.SwipeDirection.Right:
                    for (int index = -2; index <= 2; ++index)
                    {
                        AddSnakeNode(new Grid(index, 0));
                    }
                    break;
                case FingerGestures.SwipeDirection.Up:
                    for (int index = -2; index <= 2; ++index)
                    {
                        AddSnakeNode(new Grid(0, index));
                    }
                    break;
                case FingerGestures.SwipeDirection.Down:
                    for (int index = 2; index >= -2; --index)
                    {
                        AddSnakeNode(new Grid(0, index));
                    }
                    break;
            }
            FingerGestures.OnGestureEvent += OnGestureHandler;
        }
        public void Stop()
        {
            snakeNodes.Clear();
            apples.Clear();
            FingerGestures.OnGestureEvent -= OnGestureHandler;
            TimerManager.Instance.RmvTimer(OnTimer);
        }
        void OnGestureHandler(Gesture gesture)
        {
            if (gesture.Recognizer == null ) { return; }
            if (gesture.Recognizer.GetType() == typeof(SwipeRecognizer))
            {
                OnFingerSwipe((SwipeGesture)gesture);
            }
        }

        public void Update()
        {
            int x = 0, z = 0;
            switch (m_direction)
            {
                case FingerGestures.SwipeDirection.Up:   z = 1; break;
                case FingerGestures.SwipeDirection.Down: z = -1; break;
                case FingerGestures.SwipeDirection.Left: x = -1; break;
                case FingerGestures.SwipeDirection.Right:x = 1; break;
            }

            var willGo = snakeNodes.First.Value;

            x = willGo.x + x;
            z = willGo.z + z;

            if (x > Col) { x = -Col; }
            else if (x < -Col) { x = Col; }

            if (z > Row) { z = -Row; }
            else if (z < -Row) { z = Row; }

            willGo = new Grid(x, z);
            var no = Occupied(snakeNodes, willGo);
            if (no != null)
            {
                onDie.Fire();
            }
            else
            {
                no = Occupied(apples, willGo);
                if (no != null)
                {
                    RmvApple(no);
                }
                else
                {
                    RmvSnakeNode(snakeNodes.Last);
                }
                AddSnakeNode(willGo);
            }
        }
        public void Turn(FingerGestures.SwipeDirection dir)
        {
            if( (dir & FingerGestures.SwipeDirection.Horizontal) != 0 &&
                (m_direction & FingerGestures.SwipeDirection.Horizontal) != 0 ||
                (dir & FingerGestures.SwipeDirection.Vertical) != 0 &&
                (m_direction & FingerGestures.SwipeDirection.Vertical) != 0) { return; }

            m_direction = dir;
        }
        void OnFingerSwipe(SwipeGesture gesture)
        {
            Turn(gesture.Direction);
        }
        void OnFingerSwipe(int fingerIndex, Vector2 startPos, FingerGestures.SwipeDirection direction, float velocity)
        {
            Turn(direction);
        }
        void AddSnakeNode(Grid coord)
        {
            snakeNodes.AddFirst(coord);
            var script = IGameObj.Load<SnakeObj>(new EntityId(ObjType.Snake, coord.hashCode), 0);
            SceneManager.Instance.AddEntity(script, new Vector3(coord.x, 0, coord.z));
        }
        void RmvSnakeNode(LinkedListNode<Grid> no)
        {
            snakeNodes.Remove(no);
            var eId = new EntityId(ObjType.Snake, no.Value.hashCode);
            SceneManager.Instance.RmvEntity(eId);
        }
        void AddApple(Grid coord, int moduleId)
        {
            apples.AddFirst(coord);
            var script = IGameObj.Load<AppleObj>(new EntityId(ObjType.SnakeApple, coord.hashCode), moduleId);
            SceneManager.Instance.AddEntity(script, new Vector3(coord.x, 0 , coord.z));
        }
        void RmvApple(LinkedListNode<Grid> no)
        {
            apples.Remove(no);
            var eId = new EntityId(ObjType.SnakeApple, no.Value.hashCode);
            SceneManager.Instance.RmvEntity(eId);
            //get award
        }
        void OnTimer()
        {
            Update();
            if (apples.Count < 3)
            {
                int remain = apples.Count << 2;
                if (remain <= 0) { remain = 1; }
                if (Random.Range(0, remain) == 0)
                {
                    var coords = new List<Grid>((Row * 2 + 1) * (Col * 2 + 1));
                    for (int col = -Col; col <= Col; ++col)
                    {
                        for (int row = -Row; row <= Row; ++row)
                        {
                            var coord = new Grid(col, row);
                            if (Occupied(snakeNodes, coord) == null && Occupied(apples, coord) == null)
                            {
                                coords.Add(coord);
                            }
                        }
                    }
                    AddApple(coords[Random.Range(0, coords.Count)], 0);
                }
            }
        }
        LinkedListNode<Grid> Occupied(LinkedList<Grid> nodes, Grid coord)
        {
            var no = nodes.First;
            while (no != null)
            {
                if (coord == no.Value) { return no; }
                no = no.Next;
            }
            return null;
        }
    }
}
