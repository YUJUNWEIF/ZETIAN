﻿using UnityEngine;
using System.Collections.Generic;

namespace geniusbaby.smallgame
{
    public class AwardThrower : IGameObj
    {
        const int Big = 1;
        const int Mid = 2;
        const int Small = 3;
        const int Money = 1;
        const int Coin = 2;
        const int Exp = 3;

        public Transform m;
        public Transform max;
        public Transform min;
        int m_uniqueId = 0;
        float m_moveTime;
        float m_workTime;
        float m_nextTime;
        public override void Initialize(EntityId entityId, int moduleId)
        {
            base.Initialize(entityId, moduleId);
            m = Util.UnityHelper.FindChildRecursively(SceneManager.Instance.scene.transform, @"M");
            min = Util.UnityHelper.FindChildRecursively(m, "A");
            max = Util.UnityHelper.FindChildRecursively(m, "B");
            Move();
        }
        public void StartWork()
        {
            TimerManager.Instance.AddTimer(OnUpdate, 1f);
            BatchThrow();
        }
        public void StopWork()
        {
            TimerManager.Instance.RmvTimer(OnUpdate);
        }
        void BatchThrow()
        {
            var duration = Random.Range(2, 10);
            m_nextTime = Time.time + duration;
            m_workTime = Time.time + duration * Random.Range(0.4f, 0.7f);
        }
        void Move()
        {
            var direction = (max.position - min.position).normalized * (Random.Range(0, 2) == 0 ? 1 : -1);
            velocity = direction* maxSpeed;
            m_moveTime = Time.time + Random.Range(0, max.position.x - min.position.x) / maxSpeed;            
        }
        void Update()
        {
            if (Time.time < m_moveTime)
            {
                var position = transform.position;
                position += (velocity * Time.deltaTime);
                float x = Mathf.Clamp(position.x, min.position.x, max.position.x);
                if (!Mathf.Approximately(x, position.x))
                {
                    Move();
                }
                position.x = x;
                transform.position = position;
            }
            else
            {
                Move();
            }
        }
        public override void OnUpdate()
        {
            if (Time.time < m_workTime)
            {
                var eId = new EntityId(ObjType.Award, ++m_uniqueId);
                int mId = CalAwardType() * 100 + CalScaleType();
                var script = IGameObj.Load<AwardObj>(eId, mId);
                SceneManager.Instance.AddEntity(script, transform);
            }
            else if (Time.time > m_nextTime)
            {
                BatchThrow();
            }
        }
        int CalAwardType()
        {
            var awardType = Exp;
            int rate = Random.Range(0, 100);
            if (rate < 10) { awardType = Money; }
            else if (rate < 30) { awardType = Coin; }
            else { awardType = Exp; }
            return awardType;
        }
        int CalScaleType()
        {
            var scaleType = Small;
            int rate = Random.Range(0, 100);
            if (rate < 10) { scaleType = Big; }
            else if (rate < 30) { scaleType = Mid; }
            else { scaleType = Small; }
            return scaleType;
        }
    }
}
