﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;
using System.Collections.Generic;
using System.Collections;

namespace geniusbaby.smallgame
{
    public class AppleObj : steering.IBaseObj { }
}
