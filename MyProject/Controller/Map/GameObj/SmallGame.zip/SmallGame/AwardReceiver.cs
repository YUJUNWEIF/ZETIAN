﻿using UnityEngine;
using System;
using System.Collections.Generic;

namespace geniusbaby.smallgame
{
    public class AwardReceiver : ObserveRole
    {
        public Transform transport;
        public Transform max;
        public Transform min;
        public override void Initialize(EntityId entityId, int moduleId)
        {
            base.Initialize(entityId, moduleId);
            maxSpeed = 20f;
            transport = Util.UnityHelper.FindChildRecursively(SceneManager.Instance.scene.transform, @"Transport");
            min = Util.UnityHelper.FindChildRecursively(transport, "A");
            max = Util.UnityHelper.FindChildRecursively(transport, "B");
        }
        void Update()
        {
            if (!Util.UnityHelper.IsComputer())
            {
                acceleration = Input.acceleration * 10;
                acceleration.z = 0;
            }
            CaculateVelocity();
            var deltaPosition = velocity * Time.deltaTime;
            var position = transform.position;
            position.x += deltaPosition.x;
            float x = Mathf.Clamp(position.x, min.position.x, max.position.x);
            if (!Mathf.Approximately(x, position.x))
            {
                velocity = Vector3.zero;
            }
            position.x = x;
            transform.position = position;
        }
    }
}
