﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

namespace geniusbaby.smallgame
{
    public class AwardObj : steering.IBaseObj
    {
        float speed;
        const float accelerate = 10f;
        public override void Initialize(EntityId entityId, int moduleId)
        {
            base.Initialize(entityId, moduleId);
            var script = gameObject.GetComponent<Rigidbody>();
            if (script == null) { script = gameObject.AddComponent<Rigidbody>(); }
            script.isKinematic = false;
            script.useGravity = false;
            Util.UnityHelper.Register(this, EventTriggerType.PointerClick, ev =>
            {
                AwardControl.Instance.Collect(this);
            });
        }
        void Update()
        {
            speed += Time.deltaTime * accelerate;
            var loc = transform.localPosition;
            loc.y -= speed * Time.deltaTime;
            if (loc.y < -1000) { AwardControl.Instance.OutOfView(entityId); }
            else { transform.localPosition = loc; }
        }
        void OnTriggerEnter(Collider other)
        {
            var script = other.GetComponent<AwardReceiver>();
            if (script != null)
            {
                Debug.LogError("trigger happen!");
                AwardControl.Instance.Collect(this);
            }
        }
        //void OnCollisionEnter(Collision collision)
        //{
        //    var script = collision.transform.GetComponent<AwardReceiver>();
        //    if (script != null)
        //    {
        //        Debug.LogError("collider happen!");
        //        AwardControl.Instance.Collect(this);
        //    }
        //    //switch (collision.gameObject.tag)
        //    //{
        //    //    case "math": DoReply<MathClick>(collision); break;
        //    //    case "letter": DoReply<LetterClick>(collision); break;
        //    //    case "english": DoReply<EnglishClick>(collision); break;
        //    //    default: break;
        //    //}
        //}
    }
}