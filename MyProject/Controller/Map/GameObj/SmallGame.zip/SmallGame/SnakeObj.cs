﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using geniusbaby;

namespace geniusbaby.smallgame
{
    public class SnakeObj : steering.IBaseObj { }
}